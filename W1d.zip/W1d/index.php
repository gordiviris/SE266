<?php

//creating assignment
$todo = [
    //name of attribute => value
    'Title' => 'Clean bedroom',
    'Due' => 'Monday',
    'Assigned_to' => 'Kevin',
    'Completed' => 'no'
];

//linking to othe file where html is
require 'index.view.php';