<?php

$animals = ['Monkey','Hippo','Zebra','Tiger','Lions'];

require 'index.view.php';