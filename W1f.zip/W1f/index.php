<?php
require 'functions.php';

$animals = ['dog', 'cat'];

dd($animals);
//linking to othe file where html is
require 'index.view.php';