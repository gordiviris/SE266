<?php

//creating assignment
$todo = [
    //name of attribute => value
    'title' => 'Clean bedroom',
    'due' => 'Monday',
    'assigned_to' => 'Kevin',
    'started' => true,
    'completed' => false
];

//linking to othe file where html is
require 'index.view.php';